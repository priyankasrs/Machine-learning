import os
from flask import session
import tablib
from flask_session import Session
from flask import Flask, request, redirect, url_for, render_template,flash
from werkzeug.utils import secure_filename
from flask import send_from_directory

UPLOAD_FOLDER = '/home/priyanka/Documents/FlaskProject_v01/uploads/'
ALLOWED_EXTENSIONS = set(['csv'])

app = Flask(__name__,template_folder='template')
sess = Session()

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def student():
   return '''
  <html>
   <body>
   <h1>Welcome to the Official Hospital website</h1>
      <form action = "http://localhost:5000/uploadFile" method = "POST">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="uname" required>
	</br>
	</br>
      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
		</br></br>
      <button type="submit">Login</button>
	</br></br>
      <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>

      </form>
      
   </body>
</html>
    '''

@app.route('/uploadFile', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit a empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return redirect(url_for('uploaded_file',
                                    filename=filename))
    return render_template("uploadFile.html")

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    dataset = tablib.Dataset()
    with open(os.path.join(os.path.dirname(__file__),filename),encoding="utf8",errors='ignore') as f:
      dataset.csv = f.read()	
    return dataset.html

if __name__ == '__main__':
    app.secret_key = 'super secret key'
    app.config['SESSION_TYPE'] = 'filesystem'

    sess.init_app(app)

    app.debug = True
    app.run()
